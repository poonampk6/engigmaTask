package pom;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.poifs.crypt.temp.EncryptedTempData;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import fileUtility.ExcelFIle;

public class noKodrPom
{
	ExcelFIle Exc = new ExcelFIle();
	public noKodrPom(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
	}
	
	private @FindBy (xpath = "//a[text()='Sign up']")
	WebElement signupPage;
	
	public WebElement getSignUp()
	{
		return signupPage;
	}
	
	public void signup()
	{
		signupPage.click();
	}
	
	private @FindBy (xpath = "(//input[@type='email'])[2]")
	WebElement userEmail;
	
	public WebElement getEmail()
	{
		return userEmail;
	}
	
	public void Email() throws EncryptedDocumentException, IOException
	{
		String Email = Exc.getData("Sheet1", 0, 1);
		userEmail.sendKeys(Email);
	}
	
	private @FindBy (css = "label[class='slds-checkbox__label']")
	WebElement termsAndConditions;
	
	public WebElement getcheckBox()
	{
		return termsAndConditions;
	}
	
	public void clickCheckBox()
	{
		termsAndConditions.click();
	}

	private @FindBy (xpath = "//div[text()='Proceed']")
	WebElement Proceed ;
	
	public WebElement getProceed()
	{
		return Proceed;
	}
	
	public void clickProceed()
	{
		Proceed.click();
	}	
	
	//verification code
	private @FindBy(xpath="//input[@name='code']")
	WebElement verificationCode;
	
	public WebElement getCode()
	{
		return verificationCode;
	}
	
	public void Code()
	{
		verificationCode.click();
	}
	
	private @FindBy(xpath="//div[text()='Verify Code']")
	WebElement VerifyCode;
	
	public WebElement getVCode()
	{
		//VerifyCode.sendKeys("");
		return VerifyCode;
	}
	
	public void VCode()
	{
		VerifyCode.click();
	}
	
	//Sign Up
	private @FindBy (css  = "input[name='firstName']")
	WebElement firstName ;
	
	public WebElement getfirstName()
	{
		return firstName;
	}
	
	public void EnterfirstName() throws EncryptedDocumentException, IOException
	{
		String FirstName = Exc.getData("Sheet2", 0, 1);
		firstName.sendKeys(FirstName);
	}
	
	private @FindBy (css  = "input[name='lastName']")
	WebElement lastName ;
	
	public WebElement getlastName()
	{
		return lastName;
	}
	
	public void EnterlastName() throws EncryptedDocumentException, IOException
	{
		String LastName = Exc.getData("Sheet2", 1, 1);
		lastName.sendKeys(LastName);
	}
	
	private @FindBy (xpath   = "//input[@name='password'])[2]")
	WebElement password ;
	
	public WebElement getpassword()
	{
		return password;
	}
	
	public void Enterpassword() throws EncryptedDocumentException, IOException
	{
		String Password = Exc.getData("Sheet2", 2, 1);
		password.sendKeys(Password);
	}
	 
	
	private @FindBy (css  = "input[name='password-confirmpassword']")
	WebElement confirmpassword ;
	
	public WebElement getconfirmpassword()
	{
		return confirmpassword;
	}
	
	public void Enterconfirmpassword() throws EncryptedDocumentException, IOException
	{
		String Confirmpassword = Exc.getData("Sheet2", 3, 1);
		confirmpassword.sendKeys(Confirmpassword);
	}
	
	private @FindBy (xpath   = "//div[text()='Register']")
	WebElement Register ;
	
	public WebElement getRegister()
	{
		return Register;
	}
	
	public void EnterRegister()
	{
		Register.click();
	}
	
	//Forgot password
	
	
	
	private @FindBy(xpath="//a[text()='Forgot Password?']")
	WebElement ForgotPassword;
	
	public WebElement getForgotPassword()
	{
		return ForgotPassword;	
	}
	
	public void ForgotPassword()
	{
		ForgotPassword.click();
	}
	
	private @FindBy(xpath="(//input[@name='username'])[2]")
	WebElement ForgotText;
	
	public WebElement getForgotTextField()
	{
		return ForgotText;
	}
	
	public void getForgotTextBox() throws EncryptedDocumentException, IOException
	{	
		String ForgotTextField = Exc.getData("Sheet1", 0, 1);
		ForgotText.sendKeys(ForgotTextField);
	}
	
	private @FindBy(xpath="//div[text()='Proceed']")
	WebElement forgotProceed;
	
	public WebElement forgotPasswordProceed()
	{
		return forgotProceed;
		
	}
	
	public void EnterForgotPassword() 
	{
		forgotProceed.click();
	}
	
	//Login
	private @FindBy(xpath="//a[text()='Log In']")
	WebElement Loginlink;
	
	public WebElement getLoginLink()
	{
		return Loginlink;
		
	}
	public void clickLogin()
	{
		Loginlink.click();
	}
	
	
	//Email
	@FindBy(xpath="//input[@name='username']")
	public WebElement Email;
	
	public WebElement emailTextField()
	{
		return Email;	
	}
	
	public void EnterEmail() throws EncryptedDocumentException, IOException
	{
		String userEmail = Exc.getData("Sheet1", 0, 1);
		Email.sendKeys(userEmail);
	}
	
	//Password
	private @FindBy(xpath="//input[@name='password']")
	WebElement Password;
	
	public WebElement PasswordTextField()
	{
		return Password;	
	}
	
	public void EnterPassword() throws EncryptedDocumentException, IOException
	{
		String userPassword = Exc.getData("Sheet2", 2, 1);
		Password.sendKeys(userPassword);
	}
	
	//remember me checkbox
	private @FindBy(xpath="//input[@name='rememberMe']")
	WebElement rememberMe;
	
	public WebElement checkboxRemember()
	{
		return rememberMe;	
	}
	
	public void checkboxClick() throws EncryptedDocumentException, IOException
	{
		rememberMe.click();
	}
	
	//login button
	private @FindBy(xpath="//div[text()='Log In']")
	WebElement login;
	
	public WebElement loginClick()
	{
		return login;
	}
	
	public void loginlinkClick()	
	{
		login.click();
	}
}
