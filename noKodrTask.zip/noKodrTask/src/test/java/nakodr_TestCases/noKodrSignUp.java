package nakodr_TestCases;

import java.io.IOException;
import org.testng.annotations.Test;
import baseClass.BaseClass;
import pom.noKodrPom;

public class noKodrSignUp extends BaseClass
{
	@Test
	public void signUp() throws IOException, InterruptedException
	{
		noKodrPom pom = new noKodrPom(driver);
		pom.signup();
		pom.Email();
		pom.clickCheckBox();
		pom.clickProceed();
		
		Thread.sleep(6000);
		pom.VCode();
		
		pom.EnterfirstName();
		pom.EnterlastName();
		pom.Enterpassword();
		pom.Enterconfirmpassword();	
		pom.Email();
	}
}
