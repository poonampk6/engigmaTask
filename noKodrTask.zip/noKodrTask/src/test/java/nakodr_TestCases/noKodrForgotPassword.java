package nakodr_TestCases;

import java.io.IOException;

import org.testng.annotations.Test;

import baseClass.BaseClass;
import pom.noKodrPom;

public class noKodrForgotPassword extends BaseClass
{
	@Test
	public void ForgotPassword() throws IOException, InterruptedException
	{
		noKodrPom pom = new noKodrPom(driver);
		pom.ForgotPassword();
	}

}
