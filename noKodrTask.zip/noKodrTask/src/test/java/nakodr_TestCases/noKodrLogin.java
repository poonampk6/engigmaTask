package nakodr_TestCases;

import java.io.IOException;

import org.testng.annotations.Test;

import baseClass.BaseClass;
import pom.noKodrPom;

public class noKodrLogin extends BaseClass
{
	@Test
	public void Login() throws IOException, InterruptedException
	{
		noKodrPom pom = new noKodrPom(driver);
		
		pom.getLoginLink();
		pom.EnterEmail();
		Thread.sleep(1000);
		pom.EnterPassword();
		pom.checkboxClick();
		Thread.sleep(1000);
		pom.loginlinkClick();
	}
}
